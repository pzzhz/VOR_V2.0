Load an SJPG image
"""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/sjpg/lv_example_sjpg_1
  :language: c

